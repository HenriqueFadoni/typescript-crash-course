type Quantity = 100 | 50;
type Measure = 'inch' | 'cm';

let quatity: Quantity = 50;

let measure: Measure = 'inch';