let numbers: number[] = [1, 2, 3, 4, 5];
let empty: string[] = [];
empty[0] = '0';
empty[1] = '1';

numbers.forEach(n => n.toString());
