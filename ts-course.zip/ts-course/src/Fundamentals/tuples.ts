let shop: [number, string] = [1, 'bread'];
shop.push('aa');