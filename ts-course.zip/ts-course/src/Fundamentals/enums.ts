// const small = 1;
// const medium = 2;
// const large = 3;

enum Size {
	Small,
	Medium,
	Large
};

let mySize: Size = Size.Medium;