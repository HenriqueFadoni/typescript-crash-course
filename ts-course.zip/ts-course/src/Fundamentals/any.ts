let change;
change = 1;
change = 'a';

function add(msg: any) {
	console.log(msg)
}